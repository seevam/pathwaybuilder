# Passion Projects - Standalone Application

An AI-powered project ideation and management platform that helps users discover their interests, brainstorm meaningful projects, and bring their ideas to life with personalized guidance.

## Features

### 🎯 Discovery Module (Module 1)
- **Who Am I**: Self-reflection activities to explore identity and interests
- **Values Card Sort**: Identify core values across 4 priority levels
- **Strengths Discovery**: Rate personal strengths across 4 categories
- **RIASEC Assessment**: 60-statement vocational interest assessment
- **Career Clusters Exploration**: Explore career pathways aligned with interests
- **Day in Life Research**: Deep dive into careers with structured research
- **Integration Reflection**: AI-powered synthesis of all discoveries

### 💡 Project Ideation & Brainstorming
- **AI-Powered Brainstorming**: 4-step wizard to generate project ideas
  - Select or generate interest areas based on discovery profile
  - Identify problem areas to address
  - Specify time commitment (2-3, 4-6, 7-10, 10+ hours/week)
  - Choose project types (Creative, Social Impact, Entrepreneurial, Research, Technical, Leadership)
- **Personalized Recommendations**: Ideas aligned with values, strengths, and RIASEC profile
- **Feasibility Scoring**: AI evaluates project feasibility and impact potential

### 📋 Project Planning & Management
- **Project Charter**: Define mission, vision, and SMART goals
- **Milestone Builder**: Break projects into phases with target dates
- **Resource Planner**: Plan funding, materials, space, technology, permissions, and support team
- **Skill Gap Analysis**: Identify learning needs with target proficiency levels

### 📊 Project Execution & Tracking
- **Health Score System**: Dynamic 0-100 score based on:
  - Recent activity (last check-in within 7-14 days)
  - Milestone progress
  - Task completion rate
- **Check-ins**: Log accomplishments, challenges, learnings, next steps, hours, and mood
- **Task Management**: Create tasks with descriptions and time estimates
- **Document Attachments**: Upload photos, videos, PDFs, links, and other files
- **Progress Visualization**: Timeline view of milestones and activities

## Tech Stack

- **Frontend**: Next.js 16, React, TypeScript, Tailwind CSS
- **UI Components**: shadcn/ui (Radix UI primitives)
- **Authentication**: Clerk
- **Database**: PostgreSQL with Prisma ORM
- **AI**: OpenAI GPT-4o for personalized recommendations
- **Deployment**: Vercel (recommended)

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL database
- Clerk account (for authentication)
- OpenAI API key

### Installation

1. **Clone or navigate to the repository**:
   ```bash
   cd passion-projects-app
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   ```bash
   cp .env.example .env
   ```

   Edit `.env` and fill in the required values:
   - `DATABASE_URL`: Your PostgreSQL connection string
   - `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` and `CLERK_SECRET_KEY`: Get from [Clerk Dashboard](https://dashboard.clerk.com/)
   - `OPENAI_API_KEY`: Get from [OpenAI Platform](https://platform.openai.com/api-keys)

4. **Set up the database**:
   ```bash
   # Generate Prisma client
   npx prisma generate

   # Run database migrations
   npx prisma migrate dev --name init

   # (Optional) Seed the database with Module 1 activities
   npx prisma db seed
   ```

5. **Run the development server**:
   ```bash
   npm run dev
   ```

6. Open [http://localhost:3000](http://localhost:3000) in your browser

### Clerk Setup

1. Create a new application in the [Clerk Dashboard](https://dashboard.clerk.com/)
2. Enable Email/Password authentication (or other providers as needed)
3. Configure the following URLs in Clerk settings:
   - Sign-in URL: `/sign-in`
   - Sign-up URL: `/sign-up`
   - After sign-in URL: `/dashboard`
   - After sign-up URL: `/dashboard`
4. Set up webhook for user synchronization (optional):
   - Endpoint: `https://your-domain.com/api/webhooks/clerk`
   - Events: `user.created`, `user.updated`

### Database Seeding (Optional)

To populate Module 1 activities and sample data:

1. Create a seed script in `prisma/seed.ts` (example structure provided)
2. Run: `npx prisma db seed`

## Project Structure

```
passion-projects-app/
├── src/
│   ├── app/
│   │   ├── (dashboard)/         # Protected dashboard routes
│   │   │   ├── dashboard/       # Main dashboard
│   │   │   ├── module-1/        # Discovery activities
│   │   │   └── projects/        # Project management
│   │   ├── api/                 # API routes
│   │   │   ├── activities/      # Activity completion APIs
│   │   │   ├── profile/         # User profile APIs
│   │   │   ├── projects/        # Project management APIs
│   │   │   ├── analyze-identity/   # AI identity analysis
│   │   │   ├── integration-insight/ # AI synthesis
│   │   │   └── webhooks/        # Clerk webhooks
│   │   ├── sign-in/            # Authentication pages
│   │   ├── sign-up/
│   │   └── page.tsx            # Landing page
│   ├── components/
│   │   ├── activities/         # Discovery activity components
│   │   ├── projects/           # Project-specific components
│   │   └── ui/                 # Shared UI components (shadcn)
│   ├── lib/
│   │   ├── services/           # Business logic
│   │   │   ├── project-service.ts
│   │   │   ├── milestone-service.ts
│   │   │   ├── discovery-context.ts
│   │   │   ├── module-service.ts
│   │   │   └── ai-service.ts
│   │   ├── data/               # Static data (career clusters, etc.)
│   │   ├── db.ts               # Prisma client
│   │   ├── openai.ts           # OpenAI configuration
│   │   ├── utils.ts            # Utility functions
│   │   └── validations.ts      # Zod schemas
│   └── types/                  # TypeScript types
├── prisma/
│   └── schema.prisma           # Database schema
├── .env.example                # Environment variables template
└── README.md
```

## Key Features Explained

### AI Personalization

The platform uses OpenAI GPT-4o to provide personalized recommendations throughout the user journey:

1. **Interest & Problem Generation**: Based on Module 1 discoveries (values, strengths, RIASEC code, DISC profile)
2. **Project Idea Generation**: Creates 8 unique project ideas with:
   - Feasibility scores (0-100)
   - Impact metrics
   - Uniqueness ratings (HIGH/MEDIUM/LOW)
   - Personalized alignment explanations
3. **Integration Insights**: Synthesizes all Module 1 discoveries into key themes, summaries, and actionable next steps

### Health Score Algorithm

Projects are automatically scored (0-100) based on:
- **Recent Activity (30 points)**: Last check-in within 7 days = full points, 14 days = half points
- **Milestone Progress (30 points)**: Percentage of completed milestones
- **Task Completion (20 points)**: Percentage of completed tasks
- **Base Score**: 50 points (everyone starts here)

### Discovery Flow

1. User completes Module 1 activities (Who Am I, Values, Strengths)
2. Data is saved to `ActivityCompletion.data` as JSON
3. `UserDiscoveryContext` service retrieves and structures all discovery data
4. AI uses this profile to personalize project recommendations

## Customization for White-Label

To customize the branding:

1. **App Name & Metadata**: Update in `src/app/layout.tsx`
2. **Landing Page**: Customize `src/app/page.tsx`
3. **Colors**: Edit `src/app/globals.css` (Tailwind theme)
4. **Logo**: Replace favicon in `public/` folder
5. **Activity Content**: Customize in database seed scripts

## Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project in [Vercel Dashboard](https://vercel.com/new)
3. Add environment variables in Vercel project settings
4. Deploy!

### Other Platforms

Compatible with any Node.js hosting platform:
- Railway
- Render
- Heroku
- DigitalOcean App Platform

## API Routes

### Projects
- `GET /api/projects` - Get all user projects
- `POST /api/projects` - Create new project
- `POST /api/projects/brainstorm` - Generate AI project ideas
- `POST /api/projects/generate-options` - Generate interest/problem options
- `POST /api/projects/[id]/milestones` - Manage project milestones

### Activities
- `POST /api/activities/[id]/complete` - Mark activity as complete

### Profile
- `GET /api/profile` - Get user profile
- `PATCH /api/profile` - Update user profile

### AI Insights
- `POST /api/analyze-identity` - Generate AI identity analysis
- `POST /api/integration-insight` - Generate AI integration synthesis

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | Clerk publishable key | Yes |
| `CLERK_SECRET_KEY` | Clerk secret key | Yes |
| `OPENAI_API_KEY` | OpenAI API key | Yes |
| `NEXT_PUBLIC_APP_URL` | App URL for webhooks | No |

## Troubleshooting

### Database Connection Issues
- Verify `DATABASE_URL` is correct
- Ensure PostgreSQL is running
- Check firewall rules if using remote database

### Clerk Authentication Issues
- Verify Clerk keys in `.env`
- Check Clerk Dashboard for correct redirect URLs
- Ensure middleware is configured correctly

### OpenAI API Errors
- Verify API key is valid
- Check OpenAI account has available credits
- Review rate limits if seeing 429 errors

## License

This is a standalone white-label application extracted from the Pathway Builder platform. Customize and deploy as needed for your use case.

## Support

For questions or issues, please refer to:
- Next.js: https://nextjs.org/docs
- Clerk: https://clerk.com/docs
- Prisma: https://www.prisma.io/docs
- OpenAI: https://platform.openai.com/docs
