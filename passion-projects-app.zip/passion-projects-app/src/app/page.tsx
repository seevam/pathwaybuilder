import { redirect } from 'next/navigation'
import { auth } from '@clerk/nextjs/server'
import Link from 'next/link'

export default async function Home() {
  const { userId } = await auth()

  // If user is authenticated, redirect to dashboard
  if (userId) {
    redirect('/dashboard')
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <main className="flex flex-col items-center justify-center px-6 text-center">
        <h1 className="text-6xl font-bold tracking-tight text-gray-900 mb-4">
          Passion Projects
        </h1>
        <p className="text-xl text-gray-600 mb-2 max-w-2xl">
          AI-powered project ideation and management platform
        </p>
        <p className="text-lg text-gray-500 mb-8 max-w-xl">
          Discover your interests, brainstorm meaningful projects, and bring your ideas to life with personalized guidance.
        </p>
        <div className="flex gap-4">
          <Link
            href="/sign-up"
            className="px-8 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Get Started
          </Link>
          <Link
            href="/sign-in"
            className="px-8 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
          >
            Sign In
          </Link>
        </div>
      </main>
    </div>
  )
}
